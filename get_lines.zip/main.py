import sys
from get_lines import map_cor

import requests

toponym_to_find = " ".join(sys.argv[1:])

geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"

geocoder_params = {
    "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
    "geocode": toponym_to_find,
    "format": "json"}

response = requests.get(geocoder_api_server, params=geocoder_params)

if not response:
    print('Такого места нет')

# Преобразуем ответ в json-объект
json_response = response.json()

map_api_server = "http://static-maps.yandex.ru/1.x/"
# ... и выполняем запрос
coor = map_cor(json_response)
geocoder_params = {
    "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
    "geocode": coor["ll"],
    "format": "json",
    "kind": "district"}
response = requests.get(geocoder_api_server, params=geocoder_params)

if not response:
    print('Такого места нет')

# Преобразуем ответ в json-объект
json_response = response.json()
result = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]["metaDataProperty"][
    "GeocoderMetaData"]["text"]
result = result.split(',')
print(result[2])
