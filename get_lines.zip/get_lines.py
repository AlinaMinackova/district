def map_cor(json_response):
    # Получаем первый топоним из ответа геокодера.
    toponym = json_response["response"]["GeoObjectCollection"][
        "featureMember"][0]["GeoObject"]
    # Координаты центра топонима:
    toponym_coodrinates = toponym["Point"]["pos"]
    toponym_coodrinates_lower = toponym["boundedBy"]["Envelope"]["lowerCorner"]
    toponym_coodrinates_upper = toponym["boundedBy"]["Envelope"]["upperCorner"]
    # Долгота и широта:
    toponym_longitude, toponym_lattitude = toponym_coodrinates.split(" ")
    toponym_longitude1, toponym_lattitude1 = toponym_coodrinates_lower.split(" ")
    toponym_longitude2, toponym_lattitude2 = toponym_coodrinates_upper.split(" ")
    spn = abs(float(toponym_longitude1) - float(toponym_longitude2)) / 2.0
    spn1 = abs(float(toponym_lattitude1) - float(toponym_lattitude2)) / 2.0

    # Собираем параметры для запроса к StaticMapsAPI:
    pt = f'{toponym_longitude},{toponym_lattitude},comma'
    map_params = {
        "ll": ",".join([toponym_longitude, toponym_lattitude]),
        "spn": ",".join([str(spn), str(spn1)]),
        "l": "map",
        "pt": pt
    }
    return map_params
